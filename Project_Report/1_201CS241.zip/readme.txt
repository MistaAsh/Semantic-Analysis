System Requirements to run the static website:
A web browser (Preferrably Chrome or Firefox)
Following versions are supported. 
Chrome 45+
Firefox 38+
Opera 30+
Internet Explorer 10+
Edge 12+
iOS 9+
Safari 9+
Android 4.4+

Open the index.html file to access the static website or visit the following url:

